#include "FenceRepository.h"

#include "AppPaths.h"
#include "AppVersion.h"
#include "JsonPersistence.h"

#include <windows.h>

#include <algorithm>
#include <filesystem>
#include <nlohmann/json.hpp>
#include <system_error>

namespace {

int ReadIniInt(const std::wstring& section, const std::wstring& key, int defaultValue, const std::filesystem::path& path) {
    return static_cast<int>(GetPrivateProfileIntW(section.c_str(), key.c_str(), defaultValue, path.c_str()));
}

std::wstring ReadIniString(const std::wstring& section, const std::wstring& key, const std::wstring& defaultValue, const std::filesystem::path& path) {
    wchar_t buffer[512]{};
    GetPrivateProfileStringW(section.c_str(), key.c_str(), defaultValue.c_str(), buffer, static_cast<DWORD>(std::size(buffer)), path.c_str());
    return buffer;
}

nlohmann::json RectToJson(const RECT& rect) {
    return {
        {"x", rect.left},
        {"y", rect.top},
        {"width", rect.right - rect.left},
        {"height", rect.bottom - rect.top},
    };
}

RECT RectFromJson(const nlohmann::json& jsonRect) {
    const int x = jsonRect.value("x", 40);
    const int y = jsonRect.value("y", 40);
    const int width = std::max(180, jsonRect.value("width", 360));
    const int height = std::max(120, jsonRect.value("height", 300));
    return RECT{x, y, x + width, y + height};
}

const char* DropPolicyToString(DropPolicy policy) {
    switch (policy) {
    case DropPolicy::Move:
        return "move";
    case DropPolicy::Copy:
        return "copy";
    case DropPolicy::Prompt:
        return "prompt";
    }

    return "move";
}

DropPolicy DropPolicyFromString(const std::string& value) {
    if (value == "copy") {
        return DropPolicy::Copy;
    }
    if (value == "prompt") {
        return DropPolicy::Prompt;
    }
    return DropPolicy::Move;
}

const char* FenceTypeToString(FenceType type) {
    switch (type) {
    case FenceType::Standard:
        return "standard";
    case FenceType::Portal:
        return "portal";
    }

    return "standard";
}

FenceType FenceTypeFromString(const std::string& value) {
    if (value == "portal") {
        return FenceType::Portal;
    }
    return FenceType::Standard;
}

const char* DesktopItemSourceToString(DesktopItemSource source) {
    switch (source) {
    case DesktopItemSource::Desktop:
        return "desktop";
    case DesktopItemSource::LegacyFenceFolder:
        return "legacy-folder";
    case DesktopItemSource::PortalFolder:
        return "portal-folder";
    }

    return "desktop";
}

DesktopItemSource DesktopItemSourceFromString(const std::string& value) {
    if (value == "legacy-folder") {
        return DesktopItemSource::LegacyFenceFolder;
    }
    if (value == "portal-folder") {
        return DesktopItemSource::PortalFolder;
    }
    return DesktopItemSource::Desktop;
}

} // namespace

FenceRepository::FenceRepository()
    : FenceRepository(AppPaths::GetAppDataRoot()) {
}

FenceRepository::FenceRepository(std::filesystem::path basePath)
    : m_basePath(std::move(basePath)) {
}

bool FenceRepository::Load(FenceRepositoryState& state) const {
    FenceRepositoryState loadedState;
    bool loaded = false;

    if (std::filesystem::exists(GetConfigPath())) {
        loaded = LoadFromJson(loadedState);
    } else if (std::filesystem::exists(GetLegacyIniPath())) {
        loaded = LoadFromLegacyIni(loadedState);
    }

    if (!loaded) {
        state = FenceRepositoryState{};
        state.monitorSignature = BuildMonitorSignature();
        return false;
    }

    const bool migrated = MigrateLegacyFolderBackedFences(loadedState);

    const std::wstring savedSignature = loadedState.monitorSignature;
    const std::wstring expectedSignature = BuildMonitorSignature();
    if (!savedSignature.empty() && savedSignature != expectedSignature) {
        loadedState.fences.clear();
    }

    loadedState.monitorSignature = expectedSignature;
    state = std::move(loadedState);

    if (migrated) {
        Save(state);
    }

    return true;
}

bool FenceRepository::Save(const FenceRepositoryState& state) const {
    nlohmann::json root;
    root["schemaVersion"] = 2;
    root["appVersion"] = AppVersion::kCurrentUtf8;
    root["monitorSignature"] = JsonPersistence::ToUtf8(state.monitorSignature.empty() ? BuildMonitorSignature() : state.monitorSignature);
    root["settings"] = {
        {"dropPolicy", DropPolicyToString(state.dropPolicy)},
        {"showInfoNotifications", state.showInfoNotifications},
    };
    root["fences"] = nlohmann::json::array();

    for (const FenceData& fence : state.fences) {
        nlohmann::json members = nlohmann::json::array();
        for (const DesktopItemRef& member : fence.members) {
            members.push_back({
                {"id", JsonPersistence::ToUtf8(member.itemId)},
                {"name", JsonPersistence::ToUtf8(member.displayName)},
                {"sourcePath", JsonPersistence::ToUtf8(member.sourcePath)},
                {"source", DesktopItemSourceToString(member.source)},
            });
        }

        root["fences"].push_back({
            {"id", fence.id},
            {"title", JsonPersistence::ToUtf8(fence.title)},
            {"rect", RectToJson(fence.rect)},
            {"collapsed", fence.collapsed},
            {"type", FenceTypeToString(fence.type)},
            {"portalFolder", JsonPersistence::ToUtf8(fence.portalFolder)},
            {"backingFolder", JsonPersistence::ToUtf8(fence.backingFolder)},
            {"members", std::move(members)},
        });
    }

    return JsonPersistence::SaveJsonFileAtomic(GetConfigPath(), root);
}

std::filesystem::path FenceRepository::GetConfigPath() const {
    return m_basePath / "fences.json";
}

std::filesystem::path FenceRepository::GetFenceDataRoot() const {
    return m_basePath / "FenceStorage";
}

std::filesystem::path FenceRepository::GetLegacyIniPath() const {
    return AppPaths::GetLegacyIniPath();
}

std::wstring FenceRepository::BuildMonitorSignature() {
    const int monitors = GetSystemMetrics(SM_CMONITORS);
    const int x = GetSystemMetrics(SM_XVIRTUALSCREEN);
    const int y = GetSystemMetrics(SM_YVIRTUALSCREEN);
    const int w = GetSystemMetrics(SM_CXVIRTUALSCREEN);
    const int h = GetSystemMetrics(SM_CYVIRTUALSCREEN);

    wchar_t signature[128]{};
    swprintf_s(signature, L"m=%d;x=%d;y=%d;w=%d;h=%d", monitors, x, y, w, h);
    return signature;
}

bool FenceRepository::LoadFromJson(FenceRepositoryState& state) const {
    nlohmann::json root;
    if (!JsonPersistence::TryLoadJsonFile(GetConfigPath(), root)) {
        return false;
    }

    state = FenceRepositoryState{};
    state.monitorSignature = JsonPersistence::FromUtf8(root.value("monitorSignature", std::string{}));

    if (root.contains("settings") && root["settings"].is_object()) {
        const nlohmann::json& settings = root["settings"];
        state.dropPolicy = DropPolicyFromString(settings.value("dropPolicy", std::string{"move"}));
        state.showInfoNotifications = settings.value("showInfoNotifications", true);
    }

    if (!root.contains("fences") || !root["fences"].is_array()) {
        return true;
    }

    for (const nlohmann::json& fenceJson : root["fences"]) {
        FenceData fence;
        fence.id = fenceJson.value("id", 0);
        fence.title = JsonPersistence::FromUtf8(fenceJson.value("title", std::string{"Fence"}));
        if (fence.title.empty()) {
            fence.title = L"Fence";
        }
        if (fenceJson.contains("rect") && fenceJson["rect"].is_object()) {
            fence.rect = RectFromJson(fenceJson["rect"]);
        }
        fence.collapsed = fenceJson.value("collapsed", false);
        fence.type = FenceTypeFromString(fenceJson.value("type", std::string{"standard"}));
        fence.portalFolder = JsonPersistence::FromUtf8(fenceJson.value("portalFolder", std::string{}));
        fence.backingFolder = JsonPersistence::FromUtf8(fenceJson.value("backingFolder", std::string{}));

        if (fenceJson.contains("members") && fenceJson["members"].is_array()) {
            for (const nlohmann::json& memberJson : fenceJson["members"]) {
                DesktopItemRef member;
                member.itemId = JsonPersistence::FromUtf8(memberJson.value("id", std::string{}));
                member.displayName = JsonPersistence::FromUtf8(memberJson.value("name", std::string{}));
                member.sourcePath = JsonPersistence::FromUtf8(memberJson.value("sourcePath", std::string{}));
                member.source = DesktopItemSourceFromString(memberJson.value("source", std::string{"desktop"}));
                if (member.displayName.empty() && !member.sourcePath.empty()) {
                    member.displayName = std::filesystem::path(member.sourcePath).filename().wstring();
                }
                if (member.itemId.empty()) {
                    member.itemId = member.sourcePath;
                }
                fence.members.push_back(std::move(member));
            }
        }

        state.fences.push_back(std::move(fence));
    }

    return true;
}

bool FenceRepository::LoadFromLegacyIni(FenceRepositoryState& state) const {
    const std::filesystem::path iniPath = GetLegacyIniPath();
    state = FenceRepositoryState{};
    state.dropPolicy = ParseDropPolicy(ReadIniInt(L"General", L"DropPolicy", static_cast<int>(DropPolicy::Move), iniPath));
    state.showInfoNotifications = ReadIniInt(L"General", L"ShowInfoNotifications", 1, iniPath) != 0;
    state.monitorSignature = ReadIniString(L"General", L"MonitorSignature", L"", iniPath);

    const std::wstring expectedSignature = BuildMonitorSignature();
    if (!state.monitorSignature.empty() && state.monitorSignature != expectedSignature) {
        state.fences.clear();
        return true;
    }

    const int count = ReadIniInt(L"General", L"FenceCount", 0, iniPath);
    for (int index = 0; index < count; ++index) {
        wchar_t section[32]{};
        swprintf_s(section, L"Fence%d", index + 1);

        FenceData fence;
        fence.id = ReadIniInt(section, L"Id", index + 1, iniPath);
        fence.title = ReadIniString(section, L"Title", L"Fence", iniPath);
        fence.rect.left = ReadIniInt(section, L"X", 40, iniPath);
        fence.rect.top = ReadIniInt(section, L"Y", 40, iniPath);
        fence.rect.right = fence.rect.left + ReadIniInt(section, L"W", 360, iniPath);
        fence.rect.bottom = fence.rect.top + ReadIniInt(section, L"H", 300, iniPath);
        fence.collapsed = ReadIniInt(section, L"Collapsed", 0, iniPath) != 0;
        fence.backingFolder = ReadIniString(section, L"BackingFolder", L"", iniPath);
        state.fences.push_back(std::move(fence));
    }

    return true;
}

bool FenceRepository::MigrateLegacyFolderBackedFences(FenceRepositoryState& state) const {
    bool changed = false;
    for (FenceData& fence : state.fences) {
        if (!fence.members.empty()) {
            continue;
        }

        if (fence.backingFolder.empty()) {
            continue;
        }

        fence.members = ScanFolderMembers(fence.backingFolder);
        if (!fence.members.empty()) {
            changed = true;
        }
    }

    return changed;
}

std::vector<DesktopItemRef> FenceRepository::ScanFolderMembers(const std::wstring& folderPath) {
    std::vector<DesktopItemRef> members;
    std::error_code error;
    if (folderPath.empty() || !std::filesystem::exists(folderPath, error) || error) {
        return members;
    }

    for (const std::filesystem::directory_entry& entry : std::filesystem::directory_iterator(folderPath, error)) {
        if (error) {
            break;
        }

        DesktopItemRef member;
        member.sourcePath = entry.path().wstring();
        member.itemId = member.sourcePath;
        member.displayName = entry.path().filename().wstring();
        member.source = DesktopItemSource::LegacyFenceFolder;
        members.push_back(std::move(member));
    }

    std::sort(members.begin(), members.end(), [](const DesktopItemRef& left, const DesktopItemRef& right) {
        return _wcsicmp(left.displayName.c_str(), right.displayName.c_str()) < 0;
    });

    return members;
}

DropPolicy FenceRepository::ParseDropPolicy(int value) {
    if (value == static_cast<int>(DropPolicy::Copy)) {
        return DropPolicy::Copy;
    }
    if (value == static_cast<int>(DropPolicy::Prompt)) {
        return DropPolicy::Prompt;
    }
    return DropPolicy::Move;
}
